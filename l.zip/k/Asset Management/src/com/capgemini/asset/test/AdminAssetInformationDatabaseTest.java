package com.capgemini.asset.test;

import static org.junit.Assert.*;

import org.junit.Test;

import com.capgemini.asset.bean.AssetDetails;
import com.capgemini.asset.dao.AdminAssetInformationDatabase;
import com.capgemini.asset.exception.AssetException;

public class AdminAssetInformationDatabaseTest {
    AdminAssetInformationDatabase admin=new AdminAssetInformationDatabase();
    AssetDetails asset= new AssetDetails();
    
	@Test
	public void testCheck() throws AssetException {
		asset.setUser_id("155164");
		asset.setUser_password("155164");
		assertEquals(1, admin.check(asset));
	}

	@Test
	public void testNewManagerAdd() throws AssetException {
		asset.setUser_id("155164");
		asset.setUser_name("abkaushi");
		asset.setUser_password("155164");
		asset.setUser_type("admin");
		assertEquals(1, admin.newManagerAdd(asset));
	}

	@Test
	public void testAddAsset() throws AssetException {
		asset.setAsset_name("mouse");
		asset.setAsset_desc("logitech");
		asset.setQuantity(0);
		asset.setStatus("Unavailable");
		assertEquals(1241,admin.addAsset(asset));
	}

	@Test
	public void testModifyAsset() throws AssetException {
		asset.setAsset_id(1240);
		asset.setAsset_name("mouse");
		asset.setAsset_desc("logitech");
		asset.setQuantity(0);
		asset.setStatus("Unavailable");
		assertEquals(1,admin.modifyAsset(asset));
	}

	@Test
	public void testApproveRequest() throws AssetException {
		asset.setAsset_id(140);
		assertEquals(1, admin.approveRequest(asset));
	}

	@Test
	public void testUpdateAssetName() throws AssetException {
		asset.setAsset_id(1010);
		asset.setAsset_name("keyboard");
		assertEquals(1,admin.updateAssetName(asset));
	}

	@Test
	public void testUpdateAssetDesc() throws AssetException {
		asset.setAsset_id(1010);
		asset.setAsset_desc("wireless");
		assertEquals(1,admin.updateAssetDesc(asset));
	}

	@Test
	public void testUpdateAssetQuantity() throws AssetException {
		asset.setAsset_id(1010);
		asset.setQuantity(12);
		assertEquals(1,admin.updateAssetQuantity(asset));
	}

	@Test
	public void testUpdateAssetStatus() throws AssetException {
		asset.setAsset_id(1010);
		asset.setStatus("Available");
		assertEquals(1,admin.updateAssetStatus(asset));
	}

	@Test
	public void testRejectRequest() throws AssetException {
		asset.setAllocation_id(140);
		assertEquals(1, admin.rejectRequest(asset));
	}

	@Test
	public void testInsert_into_employee() throws AssetException {
		asset.setEmp_no(10023);
		asset.setEmp_name("Shubham");
		asset.setJob("Research");
		asset.setMgr_no("155163");
		asset.setDept_id(1001);
		assertEquals(1, admin.insert_into_employee(asset));
	}

	@Test
	public void testCheckDeptId() throws AssetException {
		asset.setDept_id(1001);
		assertEquals(1, admin.checkDeptId(asset));
	}

	@Test
	public void testCheckManagerId() throws AssetException {
		asset.setMgr_no("188888");
		assertEquals(1, admin.checkManagerId(asset));
	}

}
