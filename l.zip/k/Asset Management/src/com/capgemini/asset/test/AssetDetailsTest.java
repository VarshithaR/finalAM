package com.capgemini.asset.test;

import static org.junit.Assert.*;

import org.junit.Test;

import com.capgemini.asset.bean.AssetDetails;

public class AssetDetailsTest {
	AssetDetails bean = new AssetDetails();

	@Test
	public void testGetUser_id() {
		bean.setUser_id("155164");
		assertEquals("155164", bean.getUser_id());
	}

	@Test
	public void testGetUser_name() {
		bean.setUser_name("abkauhsi");
		assertEquals("abkauhsi", bean.getUser_name());
	}

	@Test
	public void testGetUser_password() {
		bean.setUser_password("155164");
		assertEquals("155164",bean.getUser_password());
	}

	@Test
	public void testGetUser_type() {
		bean.setUser_type("MANAGER");
		assertEquals("MANAGER", bean.getUser_type());
	}

	@Test
	public void testGetDept_id() {
		bean.setDept_id(1001);
		assertEquals(1001,bean.getDept_id());
	}

	@Test
	public void testGetDept_name() {
		bean.setDept_name("r&d");
		assertEquals("r&d", bean.getDept_name());
	}

	@Test
	public void testGetEmp_no() {
		bean.setEmp_no(10023);
		assertEquals(10023,bean.getEmp_no());
	}

	@Test
	public void testGetEmp_name() {
		bean.setEmp_name("Shubham");
		assertEquals("Shubham", bean.getEmp_name());
	}

	@Test
	public void testGetJob() {
		bean.setJob("RESEARCH");
		assertEquals("RESEARCH", bean.getJob());
	}

	@Test
	public void testGetMgr_no() {
		bean.setMgr_no("155163");
		assertEquals("155163", bean.getMgr_no());
	}

	@Test
	public void testGetAsset_id() {
		bean.setAsset_id(1223);
		assertEquals(1223, bean.getAsset_id());
	}

	@Test
	public void testGetAsset_name() {
		bean.setAsset_name("keyboard");
		assertEquals("keyboard", bean.getAsset_name());
	}

	@Test
	public void testGetAsset_desc() {
		bean.setAsset_desc("wireless");
		assertEquals("wireless", bean.getAsset_desc());
	}

	@Test
	public void testGetQuantity() {
		bean.setQuantity(25);
		assertEquals(25, bean.getQuantity());
	}

	@Test
	public void testGetStatus() {
		bean.setStatus("AVAILABLE");
		assertEquals("AVAILABLE", bean.getStatus());
	}

	@Test
	public void testGetAllocation_id() {
		bean.setAllocation_id(140);
		assertEquals(140, bean.getAllocation_id());
	}

}
