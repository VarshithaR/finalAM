package com.cg.asset.service;

import java.util.ArrayList;

import com.cg.asset.dao.AdminDAO;
import com.cg.asset.dao.IAdminDAO;
import com.cg.asset.exception.AdminException;
import com.cg.asset.exception.UserException;
import com.cg.asset.bean.AssetIMBean;
import com.cg.asset.bean.AssetInvBean;

public class AdminService implements IAdminService {
    
   IAdminDAO admin1=new AdminDAO();
   IAdminDAO admin2=new AdminDAO();
   IAdminDAO admin3=new AdminDAO();
   IAdminDAO admin4=new AdminDAO();
	
	public int addAsset(AssetIMBean bean1) throws AdminException {
		
		return admin1.addAsset(bean1);
	}

	@Override
	public int validateAssetId(int assetId) throws AdminException{
	
		return admin1.validateAssetId(assetId);
	}
	

	@Override
	public int modifyAsset(AssetIMBean bean2) {
		
		return admin2.modifyAsset(bean2);
	}
   
	@Override
	public int displayAsset() {
		// TODO Auto-generated method stub
		return 0;
	}

	@Override
	public ArrayList<AssetInvBean> displayAllocationEntries() throws AdminException{
		
		return admin1.displayAllocationEntries();
		
	}

	@Override
	public int updateAssetName(int assetId,String newname) throws AdminException {
		
		return admin3.updateAssetName(assetId, newname);
	}

	@Override
	public int updateAssetDesc(int assetId,String newdesc) throws AdminException {
		
		return admin3.updateAssetDesc(assetId, newdesc);
	}

	@Override
	public int updateQuantity(int assetId,int newquant) throws AdminException {
	
		return admin3.updateQuantity(assetId, newquant);
	}

	@Override
	public int updateStatus(int assetId,String newstatus) throws AdminException {
		
		return admin3.updateStatus(assetId, newstatus);
	}

	@Override
	public int approveRequest(int approveId) {
		
		return admin3.approveRequest(approveId);
	}

	@Override
	public int validateAllocationId(int allocId) throws AdminException {
		// TODO Auto-generated method stub
		return admin3.validateAllocationId(allocId);
	}

	@Override
	public int rejectRequest(int rejectId) {
		
		return admin3.approveRequest(rejectId);
		
	}

	@Override
	public int checkAssetAvailabilty(int approveId) throws AdminException {
		
		return admin4.checkAssetAvailabilty(approveId);
	}

	@Override
	public int retrieveAssetId(int approveId) throws AdminException {
		
		return admin4.retrieveAssetId(approveId);
	}

	@Override
	public int changeQuantity(int assetid) throws AdminException {
		
		return admin4.changeQuantity(assetid);
	}

	@Override
	public int getQuantity(int recentid) throws AdminException {
		
		return admin4.getQuantity(recentid);
	}

	@Override
	public int changeStatus(int recentid) throws AdminException {
		
		return admin4.changeStatus(recentid);
	}

	@Override
	public ArrayList<AssetIMBean> displayAssetInventory() throws AdminException {
		
		return admin1.displayAssetInventory();
	}

	@Override
	public ArrayList<AssetInvBean> viewAllocatedAsset() throws AdminException {
		
		return admin1.viewAllocatedAsset();
	}

	@Override
	public ArrayList<AssetInvBean> viewUnallocatedAsset() throws AdminException {
		
		return admin1.viewUnallocatedAsset();
	}

	@Override
	public int changeReleaseDate(int approveId) throws AdminException {
		
		return admin1.changeReleaseDate(approveId);
	}

















	

}
