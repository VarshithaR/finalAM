package com.cg.asset.dao;

import java.util.ArrayList;

import com.cg.asset.bean.AssetIMBean;
import com.cg.asset.bean.AssetInvBean;
import com.cg.asset.exception.AdminException;
import com.cg.asset.exception.UserException;

public interface IAdminDAO {
	
	public int addAsset(AssetIMBean bean1) throws AdminException;
	public ArrayList<AssetIMBean> displayAssetInventory() throws AdminException;
	public int validateAssetId(int assetId) throws AdminException;
	public int updateAssetName(int assetId,String newname) throws AdminException;
	public int updateAssetDesc(int assetId,String newdesc) throws AdminException;
	public int updateQuantity(int assetId,int newquant) throws AdminException;
	public int updateStatus(int assetId,String newstatus) throws AdminException;
	public int modifyAsset(AssetIMBean bean2);
	public int displayAsset();
	public ArrayList<AssetInvBean> displayAllocationEntries() throws AdminException;
	public int approveRequest(int approveId);
	public int  validateAllocationId(int allocId) throws AdminException;
	public int rejectRequest(int rejectId);
	public int checkAssetAvailabilty(int approveId) throws AdminException;
	public int retrieveAssetId(int approveId) throws AdminException;
	public int changeQuantity(int assetid) throws AdminException;
	public int getQuantity(int recentid) throws AdminException;
	public int changeStatus(int recentid) throws AdminException;
	public ArrayList<AssetInvBean> viewAllocatedAsset() throws AdminException;
	public ArrayList<AssetInvBean> viewUnallocatedAsset() throws AdminException;
	public int changeReleaseDate(int approveId)throws AdminException;
}
