package com.cg.asset.test;

import static org.junit.Assert.*;

import org.junit.Test;

import com.cg.asset.bean.AssetIMBean;

public class AssetIMBeanTest {
   AssetIMBean insertAsset=new AssetIMBean();
	@Test
	public void testGetAssetId() {
		insertAsset.setAssetId(101);
		assertNotEquals(-101,insertAsset.getAssetId());
	}

	@Test
	public void testGetAssetName() {
		insertAsset.setAssetName("Laptop");
		assertNotEquals("@#$",insertAsset.getAssetName());
	}

	@Test
	public void testGetAssetDesc() {
		insertAsset.setAssetDesc("HP-Laptop");
		assertNotEquals("&*&",insertAsset.getAssetDesc());
	}

	@Test
	public void testGetAssetQuantity() {
		insertAsset.setAssetQuantity(10);
		assertNotEquals(-5,insertAsset.getAssetQuantity());
	}

	@Test
	public void testGetAssetStatus() {
		insertAsset.setAssetStatus("Available");
		assertNotEquals("Pending",insertAsset.getAssetStatus());
	}

}
