package com.cg.asset.test;

import static org.junit.Assert.*;

import org.junit.Test;

import com.cg.asset.bean.AssetInvBean;

public class AssetInventoryTest {
    AssetInvBean bean=new AssetInvBean();
	@Test
	public void testGetAllocationid() {
		bean.setAllocationid(501);
		assertNotEquals(499,bean.getAllocationid());
	}

	@Test
	public void testGetAssetid() {
		bean.setAssetid(100);
		assertNotEquals(99,bean.getAssetid());
	}

	@Test
	public void testGetEmpno() {
		bean.setEmpno(155100);
		assertNotEquals(144100,bean.getEmpno());
	}

	@Test
	public void testGetStatus() {
		bean.setStatus("Pending");
		assertNotEquals("Available",bean.getStatus());
	}

}
