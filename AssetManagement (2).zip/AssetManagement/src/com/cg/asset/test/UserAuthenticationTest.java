package com.cg.asset.test;

import static org.junit.Assert.*;

import org.junit.Test;

import com.cg.asset.dao.AuthenticateUserDao;
import com.cg.asset.exception.AdminException;

public class UserAuthenticationTest {
    AuthenticateUserDao user1=new AuthenticateUserDao();
	@Test
	public void testAuthenticateUser() throws AdminException {
		assertEquals(1,user1.authenticateUser("155315","varshr",1));
	}
	
	
	

}
