package com.cg.asset.bean;

public class UserAuthenBean {

	
	private String userid;
	private String pwd;
	private int option;
	public int getOption() {
		return option;
	}
	public void setOption(int option) {
		this.option = option;
	}
	public String getUserid() {
		return userid;
	}
	public void setUserid(String userid) {
		this.userid = userid;
	}
	public String getPwd() {
		return pwd;
	}
	public void setPwd(String pwd) {
		this.pwd = pwd;
	}
	
	public UserAuthenBean(String userid, String pwd,int option) {
		super();
		this.userid = userid;
		this.pwd = pwd;
		this.option=option;
	}
	public UserAuthenBean() {
		super();
		// TODO Auto-generated constructor stub
	}
	
}
