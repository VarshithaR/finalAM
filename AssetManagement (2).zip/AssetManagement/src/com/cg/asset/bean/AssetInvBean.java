package com.cg.asset.bean;

public class AssetInvBean {
    private int allocationid;
	private int assetid;
	private int empno;
	private String status;
	public int getAllocationid() {
		return allocationid;
	}
	public void setAllocationid(int allocationid) {
		this.allocationid = allocationid;
	}
	public int getAssetid() {
		return assetid;
	}
	public void setAssetid(int assetid) {
		this.assetid = assetid;
	}
	public int getEmpno() {
		return empno;
	}
	public void setEmpno(int empno) {
		this.empno = empno;
	}
	public String getStatus() {
		return status;
	}
	public void setStatus(String status) {
		this.status = status;
	}
	public AssetInvBean() {
		super();
		// TODO Auto-generated constructor stub
	}
	public AssetInvBean(int allocationid, int assetid, int empno, String status) {
		super();
		this.allocationid = allocationid;
		this.assetid = assetid;
		this.empno = empno;
		this.status = status;
	}
	
	
	
	
	
}
